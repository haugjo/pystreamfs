from tkinter import *

root = Tk()

w = Label(root, text="this will be the streamfs GUI")
w.pack()

root.mainloop()